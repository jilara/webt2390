<?php
$contactDetails = [
    'address' => '123 Flower Street, Garden City, NY',
    'phone' => '(555) 123-4567',
    'email' => 'contact@flowershop.com',
    
];

define('PAGE_TITLE', 'Contact Us - Flower Shop');
define('H1_TITLE', 'Contact Us');

include 'header.php';
?>